'use client'

import { useAuthStore } from '@/store/useAuthStore'
import { useEffect, useState } from 'react'
import Link from 'next/link'
export default function Header() {
  const { email } = useAuthStore()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <header className="w-full bg-gray-100 p-4 shadow">
      <div className="max-w-4xl mx-auto flex justify-between items-center">
        <h1 className="font-bold text-xl">🧠 DigiVault</h1>
        <div>
          {email ? (
              <Link href="/login" className="text-blue-600 hover:underline">
              {email}님 반갑습니다 👋
            </Link>
          ) : (
              <Link href="/login" className="text-blue-600 hover:underline">
              로그인 해주세요
            </Link>
          )}
        </div>
      </div>
    </header>
  )
}
