export default function Sidebar() {
    return (
      <aside className="w-64 bg-gray-100 h-screen p-4">
        <ul>
          <li className="mb-2"><a href="/">🏠 홈</a></li>
          <li className="mb-2"><a href="/wallet">💼 내 지갑</a></li>
          <li className="mb-2"><a href="/otc">📊 OTC 거래</a></li>
          <li><a href="/settings">⚙️ 설정</a></li>
        </ul>
      </aside>
    );
  }