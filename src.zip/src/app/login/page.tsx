'use client'

import { useAccount, useConnect, useDisconnect } from 'wagmi'
import { InjectedConnector } from 'wagmi/connectors/injected'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabaseClient'
import { loginWithEmail } from '@/lib/auth'
import { useAuthStore } from '@/store/useAuthStore'

export default function LoginPage() {
  const { address, isConnected, status } = useAccount()
  const [mounted, setMounted] = useState(false)
  const { connect } = useConnect({
    connector: new InjectedConnector(),
  })
  const { disconnect } = useDisconnect()
  const router = useRouter()

  const [id, setId] = useState('')
  const [password, setPassword] = useState('')
  const [errorMsg, setErrorMsg] = useState('')

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return
  
    const mergeWalletToEmail = async () => {
      const email = useAuthStore.getState().email
      if (!isConnected || !address || !email) return
  
      const { error } = await supabase
        .from('users')
        .update({ wallet_address: address })
        .eq('email', email)
  
      if (error) {
        console.error('💥 메타마스크 병합 실패:', error)
      } else {
        console.log('✅ 메타마스크 주소 병합 성공!')
      }
    }
  
    mergeWalletToEmail()
  }, [isConnected, address, mounted])
  

  const handleIdLogin = async () => {
    try {
      setErrorMsg('')
      const user = await loginWithEmail(id, password)
      useAuthStore.getState().setEmail(id)
      console.log('✅ 로그인 성공:', user)
      router.push('/')
    } catch (err: any) {
      setErrorMsg(err.message)
    }
  }

  if (status === 'connecting') {
    return <p>🔄 지갑 상태 확인 중...</p>
  }

  return (
    <div className="flex flex-col items-center justify-center h-screen p-4">
      <h1 className="text-2xl font-bold mb-6">🔐 로그인</h1>

      {/* ID / 비밀번호 로그인 */}
      <div className="mb-8 w-full max-w-xs space-y-4">
        <input
          type="email"
          placeholder="이메일"
          className="w-full border px-4 py-2 rounded"
          value={id}
          onChange={(e) => setId(e.target.value)}
        />
        <input
          type="password"
          placeholder="비밀번호"
          className="w-full border px-4 py-2 rounded"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {errorMsg && <p className="text-red-500 text-sm">{errorMsg}</p>}
        <button
          onClick={handleIdLogin}
          className="w-full bg-green-600 text-white py-2 rounded"
        >
          일반 로그인
        </button>
      </div>
      {/* 회원가입 링크 */}
      <div className="mt-8">
        <p className="text-sm text-gray-600 mb-2">아직 계정이 없으신가요?</p>
        <button
          onClick={() => router.push('/register')}
          className="underline text-blue-600 hover:text-blue-800"
        >
          회원가입 하러가기 →
        </button>
      </div>

      {/* 메타마스크 + 업비트 + 바이낸스 로그인 */}
        <div className="text-center space-y-4">
        <h2 className="font-bold text-lg">또는</h2>

        {isConnected ? (
            <>
            <p>🦊 연결됨: {address}</p>
            <button
                onClick={() => disconnect()}
                className="bg-red-500 text-white px-4 py-2 rounded"
            >
                로그아웃
            </button>
            </>
        ) : (
            <div className="space-y-3">
            <button
                onClick={() => connect()}
                className="bg-yellow-400 hover:bg-yellow-300 px-6 py-2 rounded font-bold w-64"
            >
                🦊 메타마스크로 로그인
            </button>
            <button
                onClick={() => alert('업비트 로그인 준비 중입니다')}
                className="bg-green-500 hover:bg-green-400 text-white px-6 py-2 rounded font-bold w-64"
            >
                🟢 업비트로 로그인
            </button>
            <button
                onClick={() => alert('바이낸스 로그인 준비 중입니다')}
                className="bg-yellow-500 hover:bg-yellow-400 text-white px-6 py-2 rounded font-bold w-64"
            >
                🟡 바이낸스로 로그인
            </button>
            </div>
        )}
        </div>
    </div>
  )
}
