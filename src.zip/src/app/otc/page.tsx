'use client'

import { useEffect, useState, useMemo } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useAccount } from 'wagmi'

interface OtcPost {
  id: string
  seller: string
  token: string
  amount: number
  price: number
  created_at: string
}


export default function OtcPage() {
  const [token, setToken] = useState('')
  const [amount, setAmount] = useState('')
  const [price, setPrice] = useState('')
  const [search, setSearch] = useState('')
  const [posts, setPosts] = useState<OtcPost[]>([])
  const { address, isConnected } = useAccount()

  const baseWallets = [
    '0xAbc1234567890000000000000000000000000000',
    '0xDef9876543210000000000000000000000000000',
    '0x1234567890abcdef1234567890abcdef12345678',
  ]
  useEffect(() => {
    console.log('✅ isConnected:', isConnected)
    console.log('✅ address:', address)
  }, [isConnected, address])

  const walletOptions = useMemo(() => {
    if (!address) return baseWallets
    return baseWallets.includes(address)
      ? baseWallets
      : [...baseWallets, address] // ✅ append
  }, [address])

  const [selectedSeller, setSelectedSeller] = useState<string>('')

  useEffect(() => {
    if (address && !baseWallets.includes(address)) {
      setSelectedSeller(address)
    } else if (baseWallets.length > 0) {
      setSelectedSeller(baseWallets[0])
    }
  }, [address])

  // 🔄 게시글 불러오기
  const fetchPosts = async () => {
    const { data, error } = await supabase
      .from('otc_posts')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) {
      console.error('게시글 불러오기 실패:', error.message)
      return
    }
    setPosts(data || [])
  }

  // ✅ 컴포넌트 마운트 시 초기 데이터 불러오기
  useEffect(() => {
    fetchPosts()
  }, [])

  // 🔐 판매글 등록
  const handleAddPost = async () => {
    if (!isConnected || !selectedSeller) {
      alert('지갑이 연결되어 있지 않습니다.')
      return
    }
    const { error } = await supabase.from('otc_posts').insert([
      {
        seller: walletOptions, // ✅ 선택한 지갑 주소 사용
        token,
        amount: parseFloat(amount),
        price: parseFloat(price),
      },
    ])
    if (error) {
      console.error('게시글 등록 실패:', error.message)
    } else {
      setToken('')
      setAmount('')
      setPrice('')
      fetchPosts()
    }

    return (
        <div>
        {/* 🔐 현재 지갑 주소 출력 (readonly) */}
        <div className="mb-4">
            <label className="font-semibold">판매 지갑 주소:</label>
            <input
            className="border p-2 w-full bg-gray-100"
            value={address ?? '지갑이 연결되지 않았습니다.'}
            readOnly
            />
        </div>
        </div>
    )
  }

  // 🔍 검색 필터링
  const filteredPosts = posts.filter(
    (post) =>
      post.token.toLowerCase().includes(search.toLowerCase()) ||
      post.seller.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">OTC 게시판 (Supabase)</h1>

      {/* 판매글 등록 */}
      <div className="mb-6">
        <input
          placeholder="토큰명"
          className="border p-2 mr-2"
          value={token}
          onChange={(e) => setToken(e.target.value)}
        />
        <input
          placeholder="수량"
          className="border p-2 mr-2"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <input
          placeholder="가격 (ETH)"
          className="border p-2 mr-2"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
        <button className="bg-blue-600 text-white px-4 py-2" onClick={handleAddPost}>
          등록
        </button>
      </div>

      {/* 검색 */}
      <div className="mb-4">
        <input
          placeholder="토큰명 또는 판매자 검색"
          className="border p-2 w-full"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label className="mr-2 font-semibold">판매 지갑 주소</label>
        <select
            value={selectedSeller}
            onChange={(e) => setSelectedSeller(e.target.value)}
            className="border p-2"
        >
            {walletOptions.map((addr) => (
            <option key={addr} value={addr}>
                {addr}
            </option>
            ))}
        </select>
        </div>

      {/* 게시글 목록 */}
      <ul className="space-y-2">
        {filteredPosts.map((post) => (
          <li key={post.id} className="border p-4 rounded">
            <p>📌 {post.token} {post.amount}개</p>
            <p>💰 가격: {post.price} ETH</p>
            <p>🧑‍💻 판매자: {post.seller}</p>
            <p>🕒 등록일: {new Date(post.created_at).toLocaleString()}</p>
          </li>
        ))}
      </ul>
    </div>
  )
}
