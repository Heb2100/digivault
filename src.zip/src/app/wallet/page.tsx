'use client'

import { useEffect } from 'react'
import { useAccount } from 'wagmi'
import { useWalletStore } from '@/store/useWalletStore'
import ConnectWallet from '@/components/ui/ConnectWallet'
import { isWalletRegistered } from '@/lib/auth'
import { fetchWalletBalances } from '@/lib/wallet'

export default function WalletPage() {
  const { address, status } = useAccount()

  const ethBalance = useWalletStore((state) => state.ethBalance)
  const tokenBalances = useWalletStore((state) => state.tokenBalances)
  const setEthBalance = useWalletStore((state) => state.setEthBalance)
  const setTokenBalances = useWalletStore((state) => state.setTokenBalances)
  

  useEffect(() => {
    const handleWallet = async () => {
      if (status === 'connected' && address) {  
        const isRegistered = await isWalletRegistered(address)
        if (!isRegistered) return
  
        const { eth, tokens } = await fetchWalletBalances(address)
        setEthBalance(eth)
        setTokenBalances(tokens)
      }
    }
    handleWallet()
  }, [status, address])

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">🦊 지갑 연결</h1>

      {/* 상태 확인 */}
      <div className="mt-4 p-4 border rounded">
        <p className="font-mono">📌 저장된 지갑 주소:</p>
      </div>

      <div className="mt-4 p-4 border rounded">
        <p className="font-mono">💰 ETH 잔액:</p>
        <p className="font-bold">{ethBalance || '조회 중...'}</p>
      </div>

      <div className="mt-4 p-4 border rounded">
        <h3 className="font-bold">📦 토큰 잔액</h3>
        <ul>
          {tokenBalances?.length > 0 ? (
            tokenBalances.map((token) => (
              <li key={token.symbol}>
                {token.symbol}: {token.balance}
              </li>
            ))
          ) : (
            <p>조회 중...</p>
          )}
        </ul>
      </div>

      {/* 지갑 연결/해제 버튼 */}
      <div className="mt-6">
        <ConnectWallet />
      </div>
    </div>
  )
}
